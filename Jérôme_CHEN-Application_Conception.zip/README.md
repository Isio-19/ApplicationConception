# Quixo | Application de conception

Fait par Jérôme CHEN.

## Lancement de l'application 

> make

